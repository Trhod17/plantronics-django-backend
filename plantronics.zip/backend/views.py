from django.contrib.auth.models import User, Group
from rest_framework import viewsets, permissions
from backend.serializers import (PlantSerializer,
                                 UserSerializer,
                                 GroupSerializer,
                                 FamilySerializer,
                                 GenusSerializer,
                                 InfoSerializer,
                                 SoilPreferenceSerializer,
                                 UserPlantSerializer,
                                 EdibleSerializer)

from backend.models import (Plant,
                            Family,
                            Genus,
                            Info,
                            SoilPreference,
                            UserPlant,
                            Edible)


class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    lookup_field = 'username'


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]


class PlantViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Plant.objects.all()
    serializer_class = PlantSerializer
    permission_classes = [permissions.IsAuthenticated]
    # lookup_field = 'plant_name'


class FamilyViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Family.objects.all()
    serializer_class = FamilySerializer
    permission_classes = [permissions.IsAuthenticated]


class GenusViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Genus.objects.all()
    serializer_class = GenusSerializer
    permission_classes = [permissions.IsAuthenticated]


class InfoViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Info.objects.all()
    serializer_class = InfoSerializer
    permission_classes = [permissions.IsAuthenticated]


class SoilPreferenceViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = SoilPreference.objects.all()
    serializer_class = SoilPreferenceSerializer
    permission_classes = [permissions.IsAuthenticated]


class UserPlantViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = UserPlant.objects.all()
    serializer_class = UserPlantSerializer
    permission_classes = [permissions.IsAuthenticated]


class EdibleViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Edible.objects.all()
    serializer_class = EdibleSerializer
    permission_classes = [permissions.IsAuthenticated]
